"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q foo`
"""


### Discussion 07 - Nonlocal, Iterators, Generators ###


####################
###   Nonlocal   ###
####################


"*** UNCOMMENT SKELETON ***"
# def among(green):
#     def us(yellow):
#         _____________________
#         yellow += ___________
#         green += ____________
#         _____________________
#         return ______________
#     return ______________
# vote = among('Red')('Blue')()


####################################
###   Iterators and Generators   ###
####################################


# For reference
def foo():
    a = 0
    if a == 0:
        print("Hello")
        yield a
        print("World")


# Q2.2 - foo
def foo():
    """
    >>> a = list(foo())
    >>> a
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    """
    "*** YOUR CODE HERE ***"


# Q2.3 - filter_gen
def filter_gen(s, f):
    """
    >>> list(filter_gen([1, 2, 3, 4, 5], lambda x: x % 2 == 0))
    [2, 4]
    >>> list(filter_gen((1, 2, 3, 4, 5), lambda x: x < 3))
    [1, 2]
    """
    "*** YOUR CODE HERE ***"


# Q2.4 - all_sums
def all_sums(lst):
    """
    >>> gen = all_sums([1, 2, 3])
    >>> sorted(gen)
    [0, 1, 2, 3, 3, 4, 5, 6]
    """
    "*** YOUR CODE HERE ***"


##########################
###   Extra Practice   ###
##########################


# Q3.1 - tree_sequence
def tree_sequence(t):
    """
    >>> t = tree(1, [tree(2, [tree(5)]), tree(3, [tree(4)])])
    >>> print(list(tree_sequence(t)))
    [1, 2, 5, 3, 4]
    """
    "*** YOUR CODE HERE ***"


### Tree ADT ###

# Constructor
def tree(label, branches=[]):
    """Construct a tree with the given label value and a list of branches."""
    for branch in branches:
        assert is_tree(branch)
    return [label] + list(branches)

# Selector
def label(tree):
    """Return the label value of a tree."""
    return tree[0]

# Selector
def branches(tree):
    """Return the list of branches of the given tree."""
    return tree[1:]

def is_tree(tree):
    """Returns True if the given tree is a tree, and False otherwise."""
    if type(tree) != list or len(tree) < 1:
        return False
    for branch in branches(tree):
        if not is_tree(branch):
            return False
    return True

# For convenience
def is_leaf(tree):
    """Returns True if the given tree's list of branches is empty, and False
    otherwise."""
    return not branches(tree)
