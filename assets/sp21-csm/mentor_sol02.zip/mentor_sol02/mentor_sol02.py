"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q is_divisible_by_4`
"""

### Discussion 02 - Python and Control ###

###################
###   Control   ###
###################

# Q2.1 - is_divisible_by_4
def is_divisible_by_4(num):
    """Write a function that returns true if a number is divisible by 4
    and false otherwise.

    >>> is_divisible_by_4(0)
    True
    >>> is_divisible_by_4(4)
    True
    >>> is_divisible_by_4(5)
    False
    >>> is_divisible_by_4(4 * 2021)
    True
    """
    return num % 4 == 0

# Q2.2 - is_leap_year
def is_leap_year(year):
    """Write a function, is_leap_year, that returns true if a number
    is a leap year and false otherwise. A leap year is a year that
    is divisible by 4 but not divisible by 400.

    >>> is_leap_year(2021)
    False
    >>> is_leap_year(2020)
    True
    >>> is_leap_year(2024)
    True
    >>> is_leap_year(2000)
    False
    """
    return year % 4 == 0 and year % 400 != 0


# Q2.3 - find_max
def find_max(x, y, z):
    """Write a function find max that will take in 3 numbers, x, y, z,
    and return the max value. Assume that x, y, and z are unique.
    Do not use Python’s built-in max function.

    >>> find_max(1, 2, 3)
    3
    >>> find_max(3, 2, 1)
    3
    >>> find_max(1, 3, 2)
    3
    >>> find_max(20, 2, 1)
    20
    >>> find_max(6, 1, 97)
    97
    """
    if x > y and x > z:
        return x
    elif y > x and y > z:
        return y
    else:
        return z

# Q2.4 - pow_of_two
def pow_of_two(n):
    """Implement pow_of_two, which takes in an integer n and prints
    all the positive, integer powers of two less than or equal to n.
    This function should return None.
    
    >>> pow_of_two(6)
    1
    2
    4
    >>> result = pow_of_two(16)
    1
    2
    4
    8
    16
    >>> result is None
    True
    """
    curr = 1
    while curr <= n:
        print(curr)
        curr *= 2 # equivalent to curr = curr * 2
