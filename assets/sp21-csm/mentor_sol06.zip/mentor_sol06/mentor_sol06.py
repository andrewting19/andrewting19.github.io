"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q wwpd_trees`
"""


### Discussion 06 - Trees and Mutation ###


#################
###   Trees   ###
#################


# Q1.1 - wwpd_trees
def wwpd_trees():
    """
    >>> t = tree(4, [tree(5), tree(2, [tree(2), tree(1)]), tree(1), tree(8, [tree(4)])])
    >>> label(t)
    4
    >>> branches(t)[1]
    [2, [2], [1]]
    >>> branches(branches(t)[1])[1]
    [1]
    """
    pass


# Q1.2 - sum_of_nodes
def sum_of_nodes(t):
    """
    >>> t = tree(4, [tree(5), tree(2, [tree(2), tree(1)]), tree(1), tree(8, [tree(4)])])
    >>> sum_of_nodes(t)
    27
    """
    total = label(t)
    for branch in branches(t):
        total += sum_of_nodes(branch)
    return total


# Q1.3 - replace_x
def replace_x(t, x):
    """
    >>> t = tree(2, [tree(2), tree(4, [tree(2)]), tree(4, [tree(2), tree(3)])])
    >>> replace_x(t, 2)
    [0, [0], [4, [0]], [4, [0], [3]]]
    """
    new_branches = [replace_x(b, x) for b in branches(t)]
    if label(t) == x:
        return tree(0, new_branches)
    return tree(label(t), new_branches)


# Q1.4 - all_paths
def all_paths(t):
    """
    >>> t = tree(2, [tree(2), tree(4, [tree(2), tree(3)])])
    >>> all_paths(t)
    [[2, 2], [2, 4, 2], [2, 4, 3]]
    """
    paths = []
    if is_leaf(t):
        paths.append([label(t)])
    else:
        for b in branches(t):
            for path in all_paths(b):
                paths.append([label(t)] + path)
    return paths


####################
###   Mutation   ###
####################


# Q2.2 - accumulate
def accumulate(lst):
    """
    >>> l = [1, 5, 13, 4]
    >>> accumulate(l)
    23
    >>> l
    [1, 6, 19, 23]
    >>> deep_l = [3, 7, [2, 5, 6], 9]
    >>> accumulate(deep_l)
    32
    >>> deep_l
    [3, 10, [2, 7, 13], 32]
    """
    sum_so_far = 0
    for i in range(len(lst)):
        item = lst[i]
        if isinstance(item, list):
            inside = accumulate(item)
            sum_so_far += inside
        else:
            sum_so_far += item
            lst[i] = sum_so_far
    return sum_so_far


#####################
###   Challenge   ###
#####################


# Q3.1 - contains_n
def contains_n(elem, n, t):
    """
    >>> t1 = tree(1, [tree(1, [tree(2)])])
    >>> contains_n(1, 2, t1)
    True
    >>> contains_n(2, 2, t1)
    False
    >>> contains_n(2, 1, t1)
    True
    >>> t2 = tree(1, [tree(2), tree(1, [tree(1), tree(2)])])
    >>> contains_n(1, 3, t2)
    True
    >>> contains_n(2, 2, t2) # Not on a path
    False
    """
    if n == 0:
        return True
    elif is_leaf(t):
        return n == 1 and label(t) == elem
    elif label(t) == elem:
        return True in [contains_n(elem, n - 1, b) for b in branches(t)]
    else:
        return True in [contains_n(elem, n, b) for b in branches(t)]


### Tree ADT ###

# Constructor
def tree(label, branches=[]):
    """Construct a tree with the given label value and a list of branches."""
    for branch in branches:
        assert is_tree(branch)
    return [label] + list(branches)

# Selector
def label(tree):
    """Return the label value of a tree."""
    return tree[0]

# Selector
def branches(tree):
    """Return the list of branches of the given tree."""
    return tree[1:]

def is_tree(tree):
    """Returns True if the given tree is a tree, and False otherwise."""
    if type(tree) != list or len(tree) < 1:
        return False
    for branch in branches(tree):
        if not is_tree(branch):
            return False
    return True

# For convenience
def is_leaf(tree):
    """Returns True if the given tree's list of branches is empty, and False
    otherwise."""
    return not branches(tree)
