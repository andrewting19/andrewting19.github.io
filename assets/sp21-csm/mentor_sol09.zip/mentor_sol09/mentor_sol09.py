"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q skip_new`
"""


### Discussion 09 - Efficiency, Linked Lists, Midterm Review ###


######################
###   Efficiency   ###
######################


def foo(n):
    for i in range(n):
        print('hello')

def foo(n):
    for i in range(n / 2):
        print('hello')      

def foo(n):
    for i in range(n ** 2 + 5):
        print('hello')   

def foo(n):
    for i in range(10000000):
        print('hello')  


def belgian_waffle(n):
    total = 0
    while n > 0:
        total += 1
        n = n // 2
    return total


########################
###   Linked Lists   ###
########################


# Q2.2 - skip_new
def skip_new(lst):
    """
    >>> a = Link(1, Link(2, Link(3, Link(4))))
    >>> a
    Link(1, Link(2, Link(3, Link(4))))
    >>> b = skip_new(a)
    >>> b
    Link(1, Link(3))
    >>> a # Original is unchanged
    Link(1, Link(2, Link(3, Link(4))))
    """
    if lst is Link.empty:
        return Link.empty
    elif lst.rest is Link.empty:
        return Link(lst.first)
    return Link(lst.first, skip_new(lst.rest.rest))


# Q2.3 - skip_mutate
def skip_mutate(lst):
    """
    >>> a = Link(1, Link(2, Link(3, Link(4))))
    >>> skip_mutate(a)
    >>> a
    Link(1, Link(3))
    """
    if lst is Link.empty or lst.rest is Link.empty:
        return
    lst.rest = lst.rest.rest
    skip_mutate(lst.rest)

    ### Iterative Solution ###
    # while lst is not Link.empty and lst.rest is not Link.empty:
    #     lst.rest = lst.rest.rest
    #     lst = lst.rest


# Q2.4 - has_cycle
def has_cycle(s):
    """
    >>> has_cycle(Link.empty)
    False
    >>> a = Link(1, Link(2, Link(3)))
    >>> has_cycle(a)
    False
    >>> a.rest.rest.rest = a
    >>> has_cycle(a)
    True
    """
    if s is Link.empty:
        return False
    slow, fast = s, s.rest
    while fast is not Link.empty:
        if fast.rest is Link.empty:
            return False
        elif fast is slow or fast.rest is slow:
            return True
        slow, fast = slow.rest, fast.rest.rest
    return False


##########################
###   Midterm Review   ###
##########################


# Q3.2 - subsets
def subsets(lst, n):
    """
    >>> three_subsets = subsets(list(range(5)), 3)
    >>> [print(subset) for subset in sorted(three_subsets)]
    [0, 1, 2]
    [0, 1, 3]
    [0, 1, 4]
    [0, 2, 3]
    [0, 2, 4]
    [0, 3, 4]
    [1, 2, 3]
    [1, 2, 4]
    [1, 3, 4]
    [2, 3, 4]
    [None, None, None, None, None, None, None, None, None, None]
    """
    if n == 0:
        return [[]]
    if len(lst) == n:
        return [lst]
    with_first = [[lst[0]] + x for x in subsets(lst[1:], n - 1)]
    without_first = subsets(lst[1:], n)
    return with_first + without_first


# Q3.3 - num_elems
def num_elems(lst):
    """
    >>> list(num_elems([3, 3, 2, 1]))
    [4]
    >>> list(num_elems([1, 3, 5, [1, [3, 5, [5, 7]]]]))
    [2, 4, 5, 8]
    """
    count = 0
    for elem in lst:
        if type(elem) is list:
            for c in num_elems(elem):
                yield c
            count += c
        else:
            count += 1

    yield count


# Q3.4 - delete_path_duplicates
def delete_path_duplicates(t):
    """
    >>> t = Tree(1, [Tree(2, [Tree(1), Tree(1)])])
    >>> delete_path_duplicates(t)
    >>> t
    Tree(1, [Tree(2, [Tree(-1), Tree(-1)])])
    >>> t2 = Tree(1, [Tree(2), Tree(2, [Tree(2, [Tree(1, [Tree(5)])])])])
    >>> delete_path_duplicates(t2)
    >>> t2
    Tree(1, [Tree(2), Tree(2, [Tree(-1, [Tree(-1, [Tree(5)])])])])
    """
    def helper(t, seen_so_far):
        if t.label in seen_so_far:
            t.label = -1
        else:
            seen_so_far = seen_so_far + [t.label]
        for b in t.branches:
            helper(b, seen_so_far)
    helper(t, [])


# Q3.5 - factor_tree
def factor_tree(n):
    """
    >>> factor_tree(20)
    Tree(20, [Tree(2), Tree(10, [Tree(2), Tree(5)])])
    >>> factor_tree(1)
    Tree(1)
    """
    for i in range(2, n):
        if n % i == 0:
            return Tree(n, [Tree(i), factor_tree(n // i)])
    return Tree(n)


class Link:
    """A linked list.

    >>> s = Link(1)
    >>> s.first
    1
    >>> s.rest is Link.empty
    True
    >>> s = Link(2, Link(3, Link(4)))
    >>> s.first = 5
    >>> s.rest.first = 6
    >>> s.rest.rest = Link.empty
    >>> s                                    # Displays the contents of repr(s)
    Link(5, Link(6))
    >>> s.rest = Link(7, Link(Link(8, Link(9))))
    >>> s
    Link(5, Link(7, Link(Link(8, Link(9)))))
    >>> print(s)                             # Prints str(s)
    <5 7 <8 9>>
    """
    empty = ()

    def __init__(self, first, rest=empty):
        assert rest is Link.empty or isinstance(rest, Link)
        self.first = first
        self.rest = rest

    def __repr__(self):
        if self.rest is not Link.empty:
            rest_repr = ', ' + repr(self.rest)
        else:
            rest_repr = ''
        return 'Link(' + repr(self.first) + rest_repr + ')'

    def __str__(self):
        string = '<'
        while self.rest is not Link.empty:
            string += str(self.first) + ' '
            self = self.rest
        return string + str(self.first) + '>'


class Tree:
    """
    >>> t = Tree(3, [Tree(2, [Tree(5)]), Tree(4)])
    >>> t.label
    3
    >>> t.branches[0].label
    2
    >>> t.branches[1].is_leaf()
    True
    """

    def __init__(self, label, branches=[]):
        for b in branches:
            assert isinstance(b, Tree)
        self.label = label
        self.branches = list(branches)

    def is_leaf(self):
        return not self.branches

    def __repr__(self):
        if self.branches:
            branch_str = ', ' + repr(self.branches)
        else:
            branch_str = ''
        return 'Tree({0}{1})'.format(self.label, branch_str)

    def __str__(self):
        def print_tree(t, indent=0):
            tree_str = '  ' * indent + str(t.label) + "\n"
            for b in t.branches:
                tree_str += print_tree(b, indent + 1)
            return tree_str
        return print_tree(self).rstrip()
