"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q lambdas`
"""

### Discussion 03 - Environment Diagrams and HOFs ###

################
###   HOFs   ###
################

# Q2.4 - lambdas
def lambdas():
    """Fill in the blanks (without using any numbers in the first blank)
    such that the entire expression evaluates to 9.

    >>> lambdas()
    9
    """
    return (lambda x: lambda y: ________________)(_____)(lambda z: z*z)()


# Q2.5 - print_sum
def print_sum(a):
    """Write a function, print sum, that takes in a positive integer, a, and 
    eturns a function that does the following:
    (1) takes in a positive integer, b
    (2) prints the sum of all natural numbers from 1 to a*b
    (3) returns a higher-order function that, when called, prints the sum of all natural numbers from 1 to
    (a+b)*c, where c is another positive integer.

    >>> f = print_sum(1)
    >>> g = f(2) # 1*2 => 1 + 2
    3
    >>> h = g(4) # (1+2)*4 => 1 + 2 + ... + 11 + 12
    78
    >>> i = h(5) # (3+4)*5 => 1 + 2 + ... + 34 + 35
    630
    """
    def helper(b):
        i, total = ____________________________
        while ____________________________:
        ____________________________
        ____________________________
        print(____________________________)
        return _____________________________
    return _______________________________


# Q2.6 - mystery
def mystery(f, x):
    """
    >>> from operator import add, mul
    >>> a = mystery(add, 3)
    >>> a(4) # add(3, 4)
    7
    >>> a(12)
    15
    >>> b = mystery(mul, 5)
    >>> b(7) # mul(5, 7)
    35
    >>> b(1)
    5
    >>> c = mystery(lambda x, y: x * x + y, 4)
    >>> c(5)
    21
    >>> c(7)
    23
    """
    "*** YOUR CODE HERE ***"

