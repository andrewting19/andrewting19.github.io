"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q if_macro`
"""

### Discussion 12 - Tail Recursion, Macros ###


# Q5 - if_macro
def if_macro(condition, true_result, false_result):
    """
    >>> eval(if_macro("True", "3", "4"))
    3
    >>> eval(if_macro("0", "'if true'", "'if false'"))
    'if false'
    >>> eval(if_macro("1", "print('true')", "print('false')"))
    true
    >>> eval(if_macro("print('condition')", "print('true_result')", "print('false_result')"))
    condition
    false_result
    """
    return f"{true_result} if {condition} else {false_result}"
