"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q make_keeper`
"""

### Discussion 02 - Higher-Order Functions, Self Reference, Lambda Expressions ###


##################################
###   Higher-Order Functions   ###
##################################


# Q2 - make_keeper
def make_keeper(n):
    """Returns a function which takes one parameter cond and prints out
    all integers 1..i..n where calling cond(i) returns True.

    >>> is_even = lambda x: x % 2 == 0
    >>> make_keeper(5)(is_even)
    2
    4
    """
    def do_keep(cond):
        i = 1
        while i <= n:
            if cond(i):
                print(i)
            i += 1
    return do_keep


################################
###   Environment Diagrams   ###
################################

n = 7

def f(x):
    n = 8
    return x + 1

def g(x):
    n = 9
    def h():
        return x + 1
    return h

def f(f, x):
    return f(x + n)

f = f(g, n)
g = (lambda y: y())(f)


##########################
###   Self-Reference   ###
##########################


# Q7 - make_keeper_redux
def make_keeper_redux(n):
    """Returns a function. This function takes one parameter <cond> and prints out 
       all integers 1..i..n where calling cond(i) returns True. The returned 
       function returns another function with the exact same behavior.
    
    >>> multiple_of_4 = lambda x: x % 4 == 0
    >>> ends_with_1 = lambda x: x % 10 == 1
    >>> k = make_keeper_redux(11)(multiple_of_4)
    4
    8
    >>> k = k(ends_with_1)
    1
    11
    >>> type(k)
    <class 'function'>
    """
    # Paste your code for make_keeper here!
    def do_keep(cond):
        i = 1
        while i <= n:
            if cond(i):
                print(i)
            i += 1
        return make_keeper_redux(n)
    return do_keep


# Q9 - print_n
def print_n(n):
    """
    >>> f = print_n(2)
    >>> f = f("hi")
    hi
    >>> f = f("hello")
    hello
    >>> f = f("bye")
    done
    >>> g = print_n(1)
    >>> type(g("first")("second")("third"))
    first
    done
    done
    <class 'function'>
    """
    def inner_print(x):
        if n <= 0:
            print("done")
        else:
            print(x)
        return print_n(n - 1)
    return inner_print

