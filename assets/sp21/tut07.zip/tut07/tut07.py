from utils import *
"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q wwpd_link`
"""

### Discussion 07 - String Representation, Efficiency, Linked Lists, Mutable Trees ###


##################
###   Review   ###
##################


class Butterfly():
    def __init__(self, wings=2):
        self.wings = wings

class Monarch(Butterfly):
    def __init__(self):
        _________________________________________
        self.colors = ['orange', 'black', 'white']

class MimicButterfly(______________):
    def __init__(self, mimic_animal):
        _______________.init()
        ______________ = mimic_animal


########################
###   Linked Lists   ###
########################


ganondorf = Link('zelda', Link('young link', Link('sheik', Link.empty)))
# Q4 - wwpd_link
def wwpd_link():
    """
    >>> _______________
    'sheik'
    >>> _______________
    'young link'
    """
    pass


# Q5 - multiply_lnks
def multiply_lnks(lst_of_lnks):
    """
    >>> a = Link(2, Link(3, Link(5)))
    >>> b = Link(6, Link(4, Link(2)))
    >>> c = Link(4, Link(1, Link(0, Link(2))))
    >>> p = multiply_lnks([a, b, c])
    >>> p.first
    48
    >>> p.rest.first
    12
    >>> p.rest.rest.rest is Link.empty
    True
    """
    "*** UNCOMMENT SKELETON ***"
    # Implementation Note: you might not need all lines in this skeleton code
    # ___________________ = ___________
    # for _______________________________________:
    #     if __________________________________________:
    #         _________________________________
    #     ___________________
    # ________________________________________________________
    # ________________________________________________________

    # For an extra challenge, try writing out an iterative approach as well below!
    "*** YOUR CODE HERE ***"


# Q6 - flip_two
def flip_two(s):
    """
    >>> one_lnk = Link(1)
    >>> flip_two(one_lnk)
    >>> one_lnk
    Link(1)
    >>> lnk = Link(1, Link(2, Link(3, Link(4, Link(5)))))
    >>> flip_two(lnk)
    >>> lnk
    Link(2, Link(1, Link(4, Link(3, Link(5)))))
    """
    "*** YOUR CODE HERE ***"

    # For an extra challenge, try writing out an iterative approach as well below!
    "*** YOUR CODE HERE ***"


#################
###   Trees   ###
#################


# Q8 - find_paths
def find_paths(t, entry):
    """
    >>> tree_ex = Tree(2, [Tree(7, [Tree(3), Tree(6, [Tree(5), Tree(11)])]), Tree(1, [Tree(5)])])
    >>> find_paths(tree_ex, 5)
    [[2, 7, 6, 5], [2, 1, 5]]
    >>> find_paths(tree_ex, 12)
    []
    """
    "*** UNCOMMENT SKELETON ***"

    # paths = []
    # if _____________________________:
    #     _________________________________
    # for __________________________________:
    #     _________________________:
    #         ___________________________________________
    # ______________________    
