"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q multiply`
"""

### Discussion 03 - Recursion, Tree Recursion ###


#####################
###   Recursion   ###
#####################


# Q3 - multiply
def multiply(m, n):
    """Takes two positive integers and returns their product using recursion.

    >>> multiply(5, 3)
    15
    """
    "*** YOUR CODE HERE ***"


# Q4 - hailstone
def hailstone(n):
    """Print out the hailstone sequence starting at n, and return the number of elements in the sequence.

    >>> a = hailstone(10)
    10
    5
    16
    8
    4
    2
    1
    >>> a
    7
    """
    "*** YOUR CODE HERE ***"


##########################
###   Tree Recursion   ###
##########################


# Q7 - count_k
def count_k(n, k):
    """ Counts the number of paths up a flight of n stairs 
    when taking up to and including k steps at a time. 

    >>> count_k(3, 3) # 3, 2 + 1, 1 + 2, 1 + 1 + 1
    4
    >>> count_k(4, 4)
    8
    >>> count_k(10, 3)
    274
    >>> count_k(300, 1) # Only one step at a time
    1
    """
    "*** YOUR CODE HERE ***"

