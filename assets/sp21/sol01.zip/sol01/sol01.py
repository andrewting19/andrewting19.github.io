"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q is_prime`
"""

### Discussion 01 - Environment Diagrams, Control ###

###################
###   Control   ###
###################

def special_case():
    x = 10
    if x > 0:
        x += 2
    elif x < 13:
        x += 3
    elif x % 2 == 1:
        x += 4
    return x

def just_in_case():
    x = 10
    if x > 0:
        x += 2
    if x < 13:
        x += 3
    if x % 2 == 1:
        x += 4
    return x

def case_in_point():
    x = 10
    if x > 0:
        return x + 2
    if x < 13:
        return x + 3
    if x % 2 == 1:
        return x + 4
    return x


# Q4 - is_prime
def is_prime(n):
    """Write a function that returns True if a positive integer n is a
    prime number and False otherwise. A prime number n is a number that
    is not divisible by any numbers other than 1 and n itself.

    >>> is_prime(10)
    False
    >>> is_prime(7)
    True
    """
    if n == 1:
        return False
    k = 2
    while k < n:
        if n % k == 0:
            return False
        k += 1
    return True

# Q5 - fizzbuzz
def fizzbuzz(n):
    """Implement fizzbuzz(n), which prints numbers from 1 to n. However,
    for numbers divisible by 3, print "fizz". For numbers divisible by 5,
    print "buzz". For numbers divisibule by both 3 and 5, print "fizzbuzz".

    >>> result = fizzbuzz(16)
    1
    2
    fizz
    4
    buzz
    fizz
    7
    8
    fizz
    buzz
    11
    fizz
    13
    14
    fizzbuzz
    16
    >>> result == None
    True
    """
    i = 1
    while i <= n:
        if i % 3 == 0 and i % 5 == 0:
            print('fizzbuzz')
        elif i % 3 == 0:
            print('fizz')
        elif i % 5 == 0:
            print('buzz')
        else:
            print(i)
        i += 1

################################
###   Environment Diagrams   ###
################################

def f(x):
    return x

def g(x, y):
    if x(y):
        return not y
    return y

x = 3
x = g(f, x)
f = g(f, 0)
