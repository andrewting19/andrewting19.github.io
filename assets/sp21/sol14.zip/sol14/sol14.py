from utils import *
"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q paths`
"""

### Discussion 14 - Final Review ###


#####################
###   Recursion   ###
#####################


# Q1.1 - paths
def paths(x, y):
    """Return a list of ways to reach y from x by repeated
    incrementing or doubling.

    >>> paths(3, 5)
    [[3, 4, 5]]
    >>> sorted(paths(3, 6))
    [[3, 4, 5, 6], [3, 6]]
    >>> sorted(paths(3, 9))
    [[3, 4, 5, 6, 7, 8, 9], [3, 4, 8, 9], [3, 6, 7, 8, 9]]
    >>> paths(3, 3) # No calls is a valid path
    [[3]]
    """
    if x > y:
        return []
    elif x == y:
        return [[x]]
    else:
        a = paths(x + 1, y)
        b = paths(x * 2, y)
        return [[x] + subpath for subpath in a + b]


def merge(s1, s2):
    """ Merges two sorted lists """
    if len(s1) == 0:
        return s2
    elif len(s2) == 0:
        return s1
    elif s1[0] < s2[0]:
        return [s1[0]] + merge(s1[1:], s2)
    else:
        return [s2[0]] + merge(s1, s2[1:])


# Q1.2 - mergesort
def mergesort(seq):
    """
    >>> mergesort([3, 5, 1, 2, 4])
    [1, 2, 3, 4, 5]
    """
    if len(seq) <= 1:
        return seq
    else:
        mid = len(seq) // 2
    return merge(mergesort(seq[:mid]), mergesort(seq[mid:]))


#################
###   Trees   ###
#################


# Q2.1 - long_paths
def long_paths(tree, n):
    """Return a list of all paths in tree with length at least n.

    >>> t = Tree(3, [Tree(4), Tree(4), Tree(5)])
    >>> left = Tree(1, [Tree(2), t])
    >>> mid = Tree(6, [Tree(7, [Tree(8)]), Tree(9)])
    >>> right = Tree(11, [Tree(12, [Tree(13, [Tree(14)])])])
    >>> whole = Tree(0, [left, Tree(13), mid, right])
    >>> long_paths(whole, 4)
    [Link(0, Link(11, Link(12, Link(13, Link(14)))))]
    """
    paths = []
    if n <= 0 and tree.is_leaf():
        paths.append(Link(tree.label))
    for b in tree.branches:
        for path in long_paths(b, n - 1):
            paths.append(Link(tree.label, path))
    return paths


# Q2.2 - widest_level
def widest_level(t):
    """
    >>> sum([[1], [2]], [])
    [1, 2]
    >>> t = Tree(3, [Tree(1, [Tree(1), Tree(5)]), Tree(4, [Tree(9, [Tree(2)])])])
    >>> widest_level(t)
    [1, 5, 9]
    """
    levels = []
    x = [t]
    while x:
        levels.append([t.label for t in x])
        x = sum([t.branches for t in x], [])
    return max(levels, key=len)


###############
###   OOP   ###
###############


# Q4.1 - Emotion
class Emotion(object):
    """
    >>> Emotion.num
    0
    >>> joy = Joy()
    >>> sadness = Sadness()
    >>> Emotion.num # number of Emotion instances created
    2
    >>> joy.power
    5
    >>> joy.catchphrase() # Print Joy's catchphrase
    Think positive thoughts!
    >>> sadness.catchphrase() #Print Sad's catchphrase
    I'm positive you will get lost.
    >>> sadness.power
    5
    >>> joy.feeling(sadness) # When both Emotions have same power value, print "Together"
    Together
    >>> sadness.feeling(joy)
    Together
    >>> joy.power = 7
    >>> joy.feeling(sadness) # Print the catchphrase of the more powerful feeling before the less powerful feeling
    Think positive thoughts!
    I'm positive you will get lost.
    >>> sadness.feeling(joy)
    Think positive thoughts!
    I'm positive you will get lost.
    """
    num = 0

    def __init__(self):
        self.power = 5
        Emotion.num += 1

    def feeling(self, other):
        if self.power > other.power:
            self.catchphrase()
            other.catchphrase()
        elif other.power > self.power:
            other.catchphrase()
            self.catchphrase()
        else:
            print("Together")


class Joy(Emotion):
    def catchphrase(self):
        print("Think positive thoughts!")

class Sadness(Emotion):
    def catchphrase(self):
        print("I'm positive you will get lost.")


##########################################
###   Mutable Linked Lists and Trees   ###
##########################################


# Q5.1 - remove_duplicates
def remove_duplicates(lnk):
    """
    >>> lnk = Link(1, Link(1, Link(1, Link(1, Link(5)))))
    >>> remove_duplicates(lnk)
    >>> lnk
    Link(1, Link(5))
    """
    if lnk is Link.empty or lnk.rest is Link.empty:
        return
    if lnk.first == lnk.rest.first:
        lnk.rest = lnk.rest.rest
        remove_duplicates(lnk)
    else:
        remove_duplicates(lnk.rest)


    ### Alternate Solution ###

    # while lnk is not Link.empty and lnk.rest is not Link.empty:
    #     if lnk.first == lnk.rest.first:
    #         lnk.rest = lnk.rest.rest
    #     else:
    #         lnk = lnk.rest


######################
###   Generators   ###
######################


# Q6.1 - repeated
def repeated(f):
    """
    >>> double = lambda x: 2 * x
    >>> funcs = repeated(double)
    >>> identity = next(funcs)
    >>> double = next(funcs)
    >>> quad = next(funcs)
    >>> oct = next(funcs)
    >>> quad(1)
    4
    >>> oct(1)
    8
    >>> [g(1) for _, g in zip(range(5), repeated(lambda x: 2 * x))]
    [1, 2, 4, 8, 16]
    """
    g = lambda x: x
    while True:
        yield g
        g = (lambda g: lambda x: f(g(x)))(g)


from operator import add, mul
# Q6.2 - accumulate
def accumulate(iterable, f):
    """
    >>> list(accumulate([1, 2, 3, 4, 5], add))
    [1, 3, 6, 10, 15]
    >>> list(accumulate([1, 2, 3, 4, 5], mul))
    [1, 2, 6, 24, 120]
    """
    it = iter(iterable)
    total = next(it)
    yield total
    for element in it:
        total = f(total, element)
        yield total
