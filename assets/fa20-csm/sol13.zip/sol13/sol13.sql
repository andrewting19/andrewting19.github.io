-- ---USAGE---

-- `python3 ok -q QUESTION`

-- e.g. `python3 ok -q fish`

-- ---NOTES---

-- * to see the verbose output,

--     `python3 ok -q QUESTION -v`

-- * to test all of your functions,

--     `python3 ok`

--- Discussion 13 - Review Potpourri and SQL ---

-- Q1.1 - fish
-- Tests
-- SELECT * from q1;
-- expect Eel|9.000000000000002
-- expect Salmon|60
-- expect Tuna|7.999999999999998
-- expect Yellowtail|-6.000000000000005

CREATE TABLE fish AS
    SELECT "Salmon" AS species, 500 AS pop, 3.3 AS rate, 4 as price, 30 as pieces UNION
    SELECT "Eel", 100, 1.3, 4, 15 UNION
    SELECT "Yellowtail", 700, 2.0, 3, 30 UNION
    SELECT "Tuna", 600, 1.1, 3, 20;
    
CREATE TABLE competitor AS
    SELECT "Salmon" AS species, 2 AS price UNION
    SELECT "Eel", 3.4 UNION
    SELECT "Yellowtail", 3.2 UNION
    SELECT "Tuna", 2.6;

CREATE TABLE q1 AS
    SELECT fish.species, (fish.price - competitor.price) * pieces
    FROM fish, competitor WHERE fish.species = competitor.species;

-- Q1.2 - lucky-shirt
-- Tests
-- SELECT * from q2;
-- expect Orange|1

CREATE TABLE grades AS
    SELECT "10/31" AS day, "Music 70" AS class, 88 as Score UNION
    SELECT "9/20", "Math 1A", 72;
    
CREATE TABLE outfits AS
    SELECT "11/5" AS day, "Blue" AS color UNION
    SELECT "9/13", "Red" UNION
    SELECT "10/31", "Orange";

CREATE TABLE q2 AS
    SELECT color, count(g.day) AS cnt
    FROM outfits AS o, grades AS g
    WHERE o.day = g.day
    GROUP BY color
    ORDER BY cnt DESC
    LIMIT 1;