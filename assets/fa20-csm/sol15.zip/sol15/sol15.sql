--- Discussion 15 - Final Review ---

CREATE TABLE mentors AS
  SELECT "Catherine" AS name, "Thai" AS food, "Purple" AS color, "Notepad++" as editor, "Java" as language UNION
  SELECT "Jamie"            , "Pie"         , "Green"          , "Sublime"            , "Java" UNION
  SELECT "Alina"            , "Sushi"       , "Orange"         , "Emacs"              , "Ruby" UNION
  SELECT "Kenny"            , "Tacos"       , "Blue"           , "Vim"                , "Python" UNION
  SELECT "Ethan"            , "Ramen"       , "Green"          , "Vim"                , "Python";

-- Q7.1 - alphabetize
-- Tests
-- SELECT * from q1;
-- expect Alina|Sushi|Orange|Emacs|Ruby
-- expect Catherine|Thai|Purple|Notepad++|Java
-- expect Ethan|Ramen|Green|Vim|Python
-- expect Jamie|Pie|Green|Sublime|Java
-- expect Kenny|Tacos|Blue|Vim|Python

CREATE TABLE q1 AS
  SELECT * FROM mentors ORDER BY name;

-- Q7.2 - not-python
-- Tests
-- SELECT * from q2;
-- expect Sushi|Orange
-- expect Thai|Purple
-- expect Pie|Green

CREATE TABLE q2 AS
  SELECT food, color
  FROM mentors
  WHERE language != "Python";

-- With aliasing -- 

-- CREATE TABLE q2 AS
--   SELECT m.food, m.color
--   FROM mentors AS m
--   WHERE m.language <> "Python";

-- Q7.3 - same-language
-- Tests
-- SELECT * from q3;
-- expect Catherine|Jamie
-- expect Ethan|Kenny

CREATE TABLE q3 AS
  SELECT m1.name, m2.name
  FROM mentors AS m1, mentors AS m2
  WHERE m1.language = m2.language AND m1.name < m2.name;