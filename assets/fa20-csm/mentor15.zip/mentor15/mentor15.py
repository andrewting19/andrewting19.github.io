"""
---USAGE---

`python3 ok -q QUESTION`

e.g. `python3 ok -q DLList`

---NOTES---

* to see the verbose output,

    `python3 ok -q QUESTION -v`

* to test all of your functions,

    `python3 ok`
"""

### Discussion 15 - Final Review ###

################################
###   Environment Diagrams   ###
################################

# Q2.1 - env-prog
def f(f):
    def h(x, y):
        z = 4
        return lambda z: (x + y) * z
    def g(y):
        nonlocal g, h
        g = lambda y: y[:4]
        h = lambda x, y: lambda f: f(x + y)
        return y[3] + y[5:8]
    return h(g("sarcasm!"), g("why?"))
f = f("61a")(2)

# Q2.2 - fruit-loops
"*** UNCOMMENT SKELETON ***"
"""
fruit = [1, 2, [3, 4]]
fruit._______________________
fruit[3][2]._________________
fruit[2][2]._________________
fruit[3][3][2][2][2][1] = ___
"""

###############
###   OOP   ###
###############

# Q3.1a - DLList
class DLList:
    """
    >>> DLList(6, DLList(1)).value
    6
    >>> DLList(6, DLList(1)).next.value
    1
    >>> DLList(6, DLList(1)).prev is None
    True
    """
    empty = None

    def __init__(self, value, next=empty, prev=empty):
        ________________________________
        ________________________________
        ________________________________

# Q3.1b - add_last
    def add_last(self, value):
        """
        >>> lst = DLList(6); lst.add_last(1); lst.value; lst.next.value; lst.next.prev.value
        6
        1
        6
        """
        pointer = self
        while ________________________________:
            _____________________________________
        _______________ = DLList(____________________________)

# Q3.1c - add_first
    def add_first(self, value):
        """
        >>> lst = DLList('A'); lst.add_first(1); lst.value; lst.next.value; lst.next.prev.value; lst.add_first(6); lst.value; lst.next.next.prev.value
        1
        'A'
        1
        6
        1
        """
        old_first = DLList(____________________________)
        _______________ = _______________________________
        _______________ = _______________________________
        if ______________________________:
            _______________________________________________

#################
###   Trees   ###
#################

# Q4.1 - rotate
def rotate(t):
    """
    >>> t1 = Tree(1, [Tree(2), Tree(3, [Tree(4)]), Tree(5)]); rotate(t1); t1
    Tree(1, [Tree(3), Tree(5, [Tree(4)]), Tree(2)])
    >>> t2 = Tree(1, [Tree(2, [Tree(3), Tree(4)]), Tree(5, [Tree(6)])]); rotate(t2); t2
    Tree(1, [Tree(5, [Tree(4), Tree(3)]), Tree(2, [Tree(6)])])
    """
    "*** UNCOMMENT SKELETON ***"
    """
    branch_labels = ___________________________________
    n = len(t.branches)
    for ______________________________________:
        ______________________________________________
        ______________________________________________
        ______________________________________________
    """

######################
###   Generators   ###
######################

# Q5.1a - n_apply
def n_apply(f, n, x):
    """
    >>> n_apply(lambda x: x + 1, 3, 2)
    5
    """
    "*** UNCOMMENT SKELETON ***"
    """
    for __________________________:
        x = ________________________
    return _______________________
    """

# Q5.1b - list_gen
def list_gen(lst, f):
    """
    >>> list(list_gen([1, 2, 3], lambda x: x + 1))
    [1, 3, 3, 5, 5, 5]
    """
    "*** UNCOMMENT SKELETON ***"
    """
    for __________________________:
        yield from [_______________________________________]
    """

# Q5.2 - iter_link
def iter_link(lnk):
    """
    >>> list(iter_link(Link(1, Link(2, Link(3, Link(4))))))
    [1, 2, 3, 4]
    >>> print(Link(1, Link(Link(2, Link(3)), Link(4, Link(5)))))
    <1 <2 3> 4 5>
    >>> iter_lst2 = iter_link(Link(1, Link(Link(2, Link(3)), Link(4, Link(5))))); next(iter_lst2); next(iter_lst2); next(iter_lst2); next(iter_lst2)
    1
    2
    3
    4
    """
    if lnk is not Link.empty:
        if type(_____________________) is Link:
            _____________________________________
        else:
            _____________________________________
        _______________________________________

### Reference Code ###

class Tree:
    """A tree."""
    def __init__(self, label, branches=[]):
        self.label = label
        for branch in branches:
            assert isinstance(branch, Tree)
        self.branches = list(branches)

    def __repr__(self):
        if self.branches:
            branch_str = ', ' + repr(self.branches)
        else:
            branch_str = ''
        return 'Tree({0}{1})'.format(repr(self.label), branch_str)

    def __str__(self):
        return '\n'.join(self.indented())

    def indented(self):
        lines = []
        for b in self.branches:
            for line in b.indented():
                lines.append('  ' + line)
        return [str(self.label)] + lines

    def is_leaf(self):
        return not self.branches

class Link:
    """A linked list."""
    empty = ()

    def __init__(self, first, rest=empty):
        assert rest is Link.empty or isinstance(rest, Link)
        self.first = first
        self.rest = rest

    def __repr__(self):
        if self.rest:
            rest_repr = ', ' + repr(self.rest)
        else:
            rest_repr = ''
        return 'Link(' + repr(self.first) + rest_repr + ')'

    def __str__(self):
        string = '<'
        while self.rest is not Link.empty:
            string += str(self.first) + ' '
            self = self.rest
        return string + str(self.first) + '>'
