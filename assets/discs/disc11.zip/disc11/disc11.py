import doctest
import sys
import argparse

"""
---USAGE---

python3 disc11.py <name_of_function>

e.g. python3 disc11.py make_lambda

---NOTES---

- if you pass all the doctests, you will get no terminal output
    - if you want to see the verbose output (all output shown even if the function is correct), run this:

    python3 disc11.py <name_of_function> -v

- if you want to test all of your functions, run this:

    python3 disc11.py all

"""

### Discussion 11 ### 

#########################
###   Python Macros   ###
#########################

# Q2.1
def make_lambda(params, body):
    """
    >>> f = make_lambda("x, y", "x + y")
    >>> f(1, 2)
    3
    >>> g = make_lambda("a, b, c", "c if a > b else -c")
    >>> g(1, 2, 3)
    -3
    >>> make_lambda("f, x, y", "f(x, y)")(f, 1, 2)
    3
    """
    __________________

# Q2.2
def make_lambda_f(params, body):
    """
    >>> f = make_lambda_f("x, y", "x + y")
    >>> f(1, 2)
    3
    >>> g = make_lambda_f("a, b, c", "c if a > b else -c")
    >>> g(1, 2, 3)
    -3
    >>> make_lambda_f("f, x, y", "f(x, y)")(f, 1, 2)
    3
    """    
    __________________

### For running tests only. Not part of discussion content ###

parser = argparse.ArgumentParser(description="Test your work")
parser.add_argument("func", metavar="function_to_test", help="Function to be tested")
parser.add_argument("-v", dest="v", action="store_const", const=True, default=False, help="Verbose output")
args = parser.parse_args()
try:
    if args.func == "all":
        if args.v:
            doctest.testmod(verbose=True)
        else:
            doctest.testmod()
    else:
        if args.v:
            doctest.run_docstring_examples(globals()[args.func], globals(), verbose=True, name=args.func)
        else:
            doctest.run_docstring_examples(globals()[args.func], globals(), name=args.func)
except:
    sys.exit("Invalid Arguments")
