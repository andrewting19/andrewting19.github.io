-- ---USAGE---

-- `python3 ok -q QUESTION`

-- e.g. `python3 ok -q num_taught`

-- ---NOTES---

-- * to see the verbose output,

--     `python3 ok -q QUESTION -v`

-- * to test all of your functions,

--     `python3 ok`

--- Discussion 12 - SQL ---

-- Q5 - lecture_check
-- No Tests

-- Tutorial: This short question is meant to help refresh your memory of topics
-- covered in lecture and lab this week before tackling more challenging problems.
-- Table A has 5 rows and 4 columns, and Table B has 3 rows and 2 columns. If we
-- join table A and table B, how many rows will the resulting table contain?

-- The resulting table will have 15 rows. A join yields all combinations of a row from
-- A and a row from B, so we have 5*3=15 total rows. Notice that this solution does
-- not depend on the number of columns in A or B.

CREATE TABLE courses AS
    SELECT "John DeNero" AS professor, "CS 61C" AS course, "Sp20" AS semester UNION
    SELECT "John DeNero", "CS 61A", "Fa19" UNION
    SELECT "Dan Garcia", "CS 61C", "Sp19" UNION
    SELECT "John DeNero", "CS 61A", "Fa18" UNION
    SELECT "Dan Garcia", "CS 10", "Fa18" UNION
    SELECT "Josh Hug", "CS 61B", "Sp18" UNION
    SELECT "John DeNero", "CS 61A", "Sp18" UNION
    SELECT "John DeNero", "CS 61A", "Fa17" UNION
    SELECT "Paul Hilfinger", "CS 61A", "Fa17" UNION
    SELECT "Paul Hilfinger", "CS 61A", "Sp17" UNION
    SELECT "John DeNero", "Data 8", "Sp17" UNION
    SELECT "Josh Hug", "CS 61B", "Sp17" UNION
    SELECT "Satish Rao", "CS 70", "Sp17" UNION
    SELECT "Nicholas Weaver", "CS 61C", "Sp17" UNION
    SELECT "Gerald Friedland", "CS 61C", "Sp17" UNION
    SELECT "Dan Garcia", "CS 61C", "Fa20" UNION
    SELECT "Borivoje Nikolic", "CS 61C", "Fa20" UNION
    SELECT "Dan Garcia", "CS 61C", "Fa19" UNION
    SELECT "Miki Lustig", "CS 61C", "Fa19" UNION
    SELECT "Dan Garcia", "CS 61C", "Fa18" UNION
    SELECT "Borivoje Nikolic", "CS 61C", "Fa18";

-- Q5.1 - num_taught
-- Tests
-- SELECT * FROM num_taught;
-- expect Borivoje Nikolic|CS 61C|2
-- expect Dan Garcia|CS 10|1
-- expect Dan Garcia|CS 61C|4
-- expect Gerald Friedland|CS 61C|1
-- expect John DeNero|CS 61A|4
-- expect John DeNero|CS 61C|1
-- expect John DeNero|Data 8|1
-- expect Josh Hug|CS 61B|2
-- expect Miki Lustig|CS 61C|1
-- expect Nicholas Weaver|CS 61C|1
-- expect Paul Hilfinger|CS 61A|2
-- expect Satish Rao|CS 70|1

CREATE TABLE num_taught AS
    SELECT professor AS professor, course AS course, COUNT(*) AS times
    FROM courses GROUP BY professor, course;

-- Q5.2 - same_num
-- Tests
-- SELECT * FROM same_num;
-- expect John DeNero|Gerald Friedland|CS 61C
-- expect Miki Lustig|Gerald Friedland|CS 61C
-- expect Miki Lustig|John DeNero|CS 61C
-- expect Nicholas Weaver|Gerald Friedland|CS 61C
-- expect Nicholas Weaver|John DeNero|CS 61C
-- expect Nicholas Weaver|Miki Lustig|CS 61C

CREATE TABLE same_num AS
    SELECT a.professor, b.professor, a.course
        FROM num_taught AS a, num_taught AS b
        WHERE a.professor > b.professor
            AND a.course = b.course
            AND a.times = b.times;

-- Q5.2 - co_taught
-- Tests
-- SELECT * FROM co_taught;
-- expect Borivoje Nikolic|Dan Garcia

CREATE TABLE co_taught AS
    SELECT a.professor, b.professor
        FROM courses AS a, courses AS b
        WHERE a.professor < b.professor AND
            a.semester = b.semester and a.course = b.course
        GROUP BY a.course, a.professor, b.professor HAVING COUNT(*) > 1;